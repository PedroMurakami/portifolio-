# TodoApp - Gerenciador de Tarefas em Java

Este é um projeto de portfólio feito em Java, um **Gerenciador de Tarefas em Console**.

## Funcionalidades

- Adicionar tarefas
- Listar tarefas
- Marcar tarefas como concluídas
- Remover tarefas
- Salvar e carregar tarefas de arquivo (`tasks.txt`)

## Como usar

1. Clone o repositório
2. Compile o projeto:
```bash
javac -d bin src/main/java/com/portfolio/todo/Main.java
```
3. Execute:
```bash
java -cp bin com.portfolio.todo.Main
```
4. Digite os números das opções para gerenciar suas tarefas.

---

Feito para fins educativos e portfólio.