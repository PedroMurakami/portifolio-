package com.portfolio.todo;

import java.io.*;
import java.util.*;

public class Main {
    private static final String FILE_NAME = "tasks.txt";
    private static List<Task> tasks = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        loadTasks();
        boolean running = true;
        while (running) {
            System.out.println("\n=== Gerenciador de Tarefas ===");
            System.out.println("1. Adicionar tarefa");
            System.out.println("2. Listar tarefas");
            System.out.println("3. Marcar como concluída");
            System.out.println("4. Remover tarefa");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            String input = scanner.nextLine();

            switch (input) {
                case "1": addTask(); break;
                case "2": listTasks(); break;
                case "3": completeTask(); break;
                case "4": removeTask(); break;
                case "5": running = false; saveTasks(); System.out.println("Saindo..."); break;
                default: System.out.println("Opção inválida!");
            }
        }
    }

    private static void addTask() {
        System.out.print("Digite a descrição da tarefa: ");
        String desc = scanner.nextLine();
        tasks.add(new Task(desc));
        System.out.println("Tarefa adicionada!");
    }

    private static void listTasks() {
        if (tasks.isEmpty()) {
            System.out.println("Nenhuma tarefa encontrada.");
            return;
        }
        for (int i = 0; i < tasks.size(); i++) {
            Task t = tasks.get(i);
            System.out.printf("%d. [%s] %s%n", i + 1, t.isCompleted() ? "X" : " ", t.getDescription());
        }
    }

    private static void completeTask() {
        listTasks();
        System.out.print("Escolha o número da tarefa para marcar como concluída: ");
        try {
            int idx = Integer.parseInt(scanner.nextLine()) - 1;
            if (idx >= 0 && idx < tasks.size()) {
                tasks.get(idx).setCompleted(true);
                System.out.println("Tarefa marcada como concluída!");
            } else System.out.println("Número inválido.");
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida.");
        }
    }

    private static void removeTask() {
        listTasks();
        System.out.print("Escolha o número da tarefa para remover: ");
        try {
            int idx = Integer.parseInt(scanner.nextLine()) - 1;
            if (idx >= 0 && idx < tasks.size()) {
                tasks.remove(idx);
                System.out.println("Tarefa removida!");
            } else System.out.println("Número inválido.");
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida.");
        }
    }

    private static void saveTasks() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Task t : tasks) {
                pw.println(t.isCompleted() + ";" + t.getDescription());
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar tarefas.");
        }
    }

    private static void loadTasks() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(";", 2);
                if (parts.length == 2) {
                    Task t = new Task(parts[1]);
                    t.setCompleted(Boolean.parseBoolean(parts[0]));
                    tasks.add(t);
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar tarefas.");
        }
    }

    static class Task {
        private String description;
        private boolean completed;

        public Task(String description) {
            this.description = description;
            this.completed = false;
        }

        public String getDescription() { return description; }
        public boolean isCompleted() { return completed; }
        public void setCompleted(boolean completed) { this.completed = completed; }
    }
}