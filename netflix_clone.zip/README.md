# Netflix-style UI Clone (Demo)

Este repositório contém um **clone visual** simples do site da Netflix para **fins educativos** — apenas front-end estático (HTML/CSS/JS). Não é afiliado nem hospedado pela Netflix, e não fornece streaming nem conteúdo protegido por direitos autorais. Use como base para aprender layout, carrosséis e design responsivo.

## Conteúdo

- `index.html` — página principal estática.
- `styles.css` — estilos minimalistas inspirados no visual da Netflix.
- `script.js` — comportamento simples (carrosséis, botões de ação).
- `README.md` — este arquivo.

## Como usar

1. Clone este repositório ou baixe os arquivos.
2. Abra `index.html` no navegador (ou faça deploy em GitHub Pages).
3. Para publicar no GitHub Pages: crie um repositório, faça push dos arquivos e ative GitHub Pages nas configurações (branch `main`/`gh-pages`).

## Aviso legal

Clone UI apenas — não reimplemente ou distribua conteúdo protegido sem permissão.

---
Feito por você 🚀 — personalize cores, fontes e adicione dados reais conforme quiser.
