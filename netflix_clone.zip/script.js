// script.js - simple behavior for rows and sample data
const posters = [
  {id:1, title:'Filme A', img:'https://picsum.photos/300/450?random=11'},
  {id:2, title:'Série B', img:'https://picsum.photos/300/450?random=12'},
  {id:3, title:'Filme C', img:'https://picsum.photos/300/450?random=13'},
  {id:4, title:'Série D', img:'https://picsum.photos/300/450?random=14'},
  {id:5, title:'Filme E', img:'https://picsum.photos/300/450?random=15'},
  {id:6, title:'Filme F', img:'https://picsum.photos/300/450?random=16'},
  {id:7, title:'Série G', img:'https://picsum.photos/300/450?random=17'},
  {id:8, title:'Filme H', img:'https://picsum.photos/300/450?random=18'},
  {id:9, title:'Série I', img:'https://picsum.photos/300/450?random=19'},
  {id:10, title:'Filme J', img:'https://picsum.photos/300/450?random=20'},
];

function createPosterEl(p){
  const div = document.createElement('div');
  div.className = 'poster';
  div.innerHTML = `<img src="${p.img}" alt="${p.title}" loading="lazy"><div class="poster-title" style="display:none">${p.title}</div>`;
  div.addEventListener('click', ()=> alert(p.title + ' — (demo)'));
  return div;
}

document.addEventListener('DOMContentLoaded', ()=>{
  // fill rows
  document.querySelectorAll('.row').forEach((rowEl, idx)=>{
    const track = rowEl.querySelector('.row-track');
    // take different slices for variety
    const slice = posters.slice((idx*3)%posters.length).concat(posters.slice(0,(idx*3)%posters.length));
    slice.slice(0,10).forEach(p => track.appendChild(createPosterEl(p)));
    const prev = rowEl.querySelector('.row-prev');
    const next = rowEl.querySelector('.row-next');
    prev.addEventListener('click', ()=> scrollRow(track, -1));
    next.addEventListener('click', ()=> scrollRow(track, 1));
  });

  // start button demo
  document.getElementById('startBtn').addEventListener('click', ()=>{
    const email = document.getElementById('email').value || '(sem email)';
    alert('Obrigado! — Este é um demo. Email: ' + email);
  });
});

function scrollRow(track, dir){
  const width = track.querySelector('.poster')?.getBoundingClientRect().width || 160;
  track.scrollBy({left: dir * (width + 10) * 3, behavior: 'smooth'});
}
