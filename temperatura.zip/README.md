# Weather App - Clima em Tempo Real

Este projeto é um **app de clima em tempo real**, feito apenas com HTML, CSS e JavaScript. Ele mostra:

- Temperatura atual
- Probabilidade de chuva
- Umidade e velocidade do vento
- Layout moderno com cards e efeitos CSS

## Como usar

1. Obtenha uma chave da API do [OpenWeatherMap](https://openweathermap.org/api).
2. Substitua `YOUR_OPENWEATHERMAP_API_KEY` no arquivo `script.js` pela sua chave.
3. Abra `index.html` em qualquer navegador.
4. Digite a cidade e clique em **Buscar** para ver o clima em tempo real.

## Observações

- Projeto front-end apenas; não requer backend.
- Feito para fins educativos e de portfólio.