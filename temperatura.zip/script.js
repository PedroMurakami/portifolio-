const apiKey = 'YOUR_OPENWEATHERMAP_API_KEY'; // Coloque sua API key aqui
const searchBtn = document.getElementById('searchBtn');
searchBtn.addEventListener('click', ()=>{
  const city = document.getElementById('cityInput').value;
  if(!city) return;
  fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=pt_br`)
    .then(res => res.json())
    .then(data => {
      if(data.cod !== 200){
        alert('Cidade não encontrada');
        return;
      }
      document.getElementById('weatherInfo').style.display = 'block';
      document.getElementById('temp').textContent = Math.round(data.main.temp) + '°C';
      document.getElementById('condition').textContent = data.weather[0].description;
      document.getElementById('humidity').textContent = data.main.humidity + '%';
      document.getElementById('wind').textContent = data.wind.speed + ' m/s';
      document.getElementById('rain').textContent = data.rain ? data.rain['1h'] + ' mm' : '0 mm';
    })
    .catch(err => alert('Erro ao buscar dados'));
});